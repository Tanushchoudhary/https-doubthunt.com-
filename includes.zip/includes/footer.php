<footer>
    <div class="w-full bg-zinc-950 p-8">
        <div class="max-w-[1000px] m-auto">
            <p class="font-semibold text-zinc-600 tracking-wider">COMPANY</p>
            <hr class="bg-orange-500 h-[2px] w-[100px] border-0 mt-2 mb-4">
            <a href='#' class="text-sm text-zinc-500">About Us</a><span
                class="pl-4 pr-4 text-lg text-zinc-500">&bull;</span>
            <a href='./admin' class="text-sm text-zinc-500">Administrator</a>
            <br>
            <a href='terms.php' class="text-md text-zinc-400">Terms & Conditions</a><span
                class="pl-4 pr-4 text-lg text-zinc-500">&bull;</span>
            <a href='privacy.php' class="text-md text-zinc-400">Privacy Policy</a><span
                class="pl-4 pr-4 text-lg text-zinc-500">&bull;</span>
            <a href='refund.php' class="text-md text-zinc-400">Refund Policy</a><span
                class="pl-4 pr-4 text-lg text-zinc-500">&bull;</span>
            <a href='contact.php' class="text-md text-zinc-400">Contact</a>
            <br>
            <br>
            <p class="font-semibold text-zinc-700">&copy; Doubthunt 2024. All Right's Reserved</p>
        </div>
    </div>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="./core/js/functions.js"></script>

    <script>
        window.onload = function() {
            // Create Ask Doubt button
            var askDoubtButton = document.createElement("button");
            askDoubtButton.textContent = "Ask Doubt";
            askDoubtButton.className = "ask-doubt-button";
            askDoubtButton.onclick = function() {
                window.location.href = 'https://doubthunt.com';
            };

            // Append the button to the body of the document
            document.body.appendChild(askDoubtButton);
        };
    </script>

    <style>
        .ask-doubt-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: #cc5500;
            color: white;
            border: none;
            padding: 8px 10px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .ask-doubt-button:hover {
            background-color: #cc5500;
        }
    </style>
</footer>
