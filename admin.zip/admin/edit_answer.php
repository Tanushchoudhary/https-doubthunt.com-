<?php
include_once("./includes/connection.php");

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $answer = $_POST['answer'];
    $media = '';

    if (!empty($_FILES['image']['name'])) {
        // Handle image upload
        $targetDirectory = "../answer_uploads/";
        $targetFile = $targetDirectory . uniqid() . '.' . pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        if ($_FILES["image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $media = basename($targetFile);
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }

    if (!empty($answer) || !empty($media)) {
        $mediaUpdate = $media ? ", media='$media'" : "";
        $sql = "UPDATE `answers` SET `answer`='$answer' $mediaUpdate WHERE `id`=$id";
        $query = mysqli_query($conn, $sql);
        if ($query) {
            header("Location: answers.php");
            exit();
        } else {
            echo "Database update failed.";
        }
    } else {
        echo "Please provide either a text answer or an image answer.";
    }
}

$query = "SELECT * FROM answers WHERE id=$id";
$result = mysqli_query($conn, $query);
$answer = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Answer</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        input[type="file"] {
            display: block;
            margin-top: 5px;
        }

        img {
            display: block;
            margin-top: 10px;
            max-width: 100%;
        }

        .toggle-button {
            margin-top: 10px;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .keyboard {
            display: none;
            margin-top: 10px;
            flex-wrap: wrap;
            gap: 5px;
        }

        .keyboard button {
            padding: 5px 10px;
            margin: 2px;
            cursor: pointer;
        }

        textarea {
            display: block;
            width: 100%;
            height: 150px;
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            margin-top: 20px;
            background-color: #28a745;
            color: white;
            padding: 15px 30px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
    <script>
        function insertSymbol(symbol) {
            const textarea = document.getElementById('answer');
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const text = textarea.value;
            const before = text.substring(0, start);
            const after = text.substring(end, text.length);
            textarea.value = before + symbol + after;
            textarea.selectionStart = textarea.selectionEnd = start + symbol.length;
            textarea.focus();
        }

        function previewImage(event) {
            var input = event.target;
            var reader = new FileReader();
            reader.onload = function () {
                var dataURL = reader.result;
                var output = document.getElementById('imagePreview');
                output.src = dataURL;
                output.style.display = 'block';
            };
            reader.readAsDataURL(input.files[0]);
        }

        function toggleKeyboard() {
            const keyboard = document.querySelector('.keyboard');
            keyboard.style.display = (keyboard.style.display === 'none' || keyboard.style.display === '') ? 'flex' : 'none';
        }
    </script>
</head>
<body>
    <h1>Edit Answer</h1>
    <form action="edit_answer.php?id=<?= $id ?>" method="POST" enctype="multipart/form-data">
        <label for="answer">Type Your Answer</label>
        <textarea name="answer" id="answer"><?= htmlspecialchars($answer['answer']); ?></textarea>
        
        <label for="image">Upload Answer Image</label>
        <input type="file" name="image" id="image" accept="image/*" onchange="previewImage(event)">
        <img id="imagePreview" style="display:none;">
        <?php if ($answer['media']): ?>
            <img src="../answer_uploads/<?= $answer['media'] ?>" alt="Current Media">
        <?php endif; ?>
        

        <input type="submit" name="submit" value="Update Answer">
    </form>
</body>
</html>
