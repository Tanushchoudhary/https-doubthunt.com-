<?php include_once ("./includes/connection.php"); ?>
<?php
if (isset($_SESSION['username'])) {
} else {
    echo "<meta http-equiv=\"refresh\" content=\"0; url=index.php\">";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>

<body>
    <div class="flex flex-col sm:flex-row h-screen">
        <?php include_once ("./includes/header.php"); ?>
        <div class="p-10 flex-1 overflow-y-auto">
            <!-- Content goes here -->
            <div class="overflow-x-auto">
                <!-- Popup -->
                <?php
                if (@$_GET['errorCode'] == "1") {
                    ?>
                    <div class="mb-4 block px-4 p-2 bg-red-50 rounded-lg border-red-200 border-[1px]">
                        <span class="font-semibold text-sm text-red-600">Subject! Already Exist</span>
                    </div>
                    <?php
                }
                ?>
                <div class="flex justify-between mb-4">
                    <h1 class="text-3xl font-semibold block mb-4 inline-block">Questions</h1>
                </div>
                <table class="table-auto w-full bg-white shadow-xl">
                    <thead>
                        <tr class="bg-gray-950">
                            <th class="px-4 py-4 text-left text-xs font-semibold text-white uppercase tracking-wider">ID
                            </th>
                            <th class="px-4 py-4 text-left text-xs font-semibold text-white uppercase tracking-wider">
                                User</th>
                            <th class="px-4 py-4 text-left text-xs font-semibold text-white uppercase tracking-wider">
                                Value</th>
                            <th class="px-4 py-4 text-left text-xs font-semibold text-white uppercase tracking-wider">
                                Category</th>
                            <th class="px-4 py-4 text-left text-xs font-semibold text-white uppercase tracking-wider">
                                Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        $sql = "SELECT * FROM `questions` ORDER BY `dateTime` DESC";
                        $query = mysqli_query($conn, $sql);
                        while ($rows = mysqli_fetch_assoc($query)) {
                            $Qid = $rows['id'];
                            $userID = $rows['userID'];

                            //User Query
                            $sql2 = "SELECT * FROM `users` WHERE `id`='$userID'";
                            $query2 = mysqli_query($conn, $sql2);
                            $rows2 = mysqli_fetch_assoc($query2);
                            $providerName = $rows2['full_name'];
                            //End Of User
                        
                            $question = $rows['question'];
                            $media = $rows['media'];
                            $categoryID = $rows['categoryID'];

                            //CategoryID Query
                            $sql3 = "SELECT * FROM `config_subject` WHERE `id`='$categoryID'";
                            $query3 = mysqli_query($conn, $sql3);
                            $rows3 = mysqli_fetch_assoc($query3);
                            $subjectValue = $rows3["value"];
                            //End CategoryID Query
                        
                            $dateTime = $rows['dateTime'];
                            $i++;
                            ?>
                            <tr class="border-b border-gray-200">
                                <td class="px-4 py-4 whitespace-nowrap">Q : #<?= $Qid ?></td>
                                <td class="px-4 py-4 whitespace-nowrap"><?= $providerName ?></td>
                                <td class="px-4 py-4 whitespace-nowrap"><?= $question ?></td>
                                <td class="px-4 py-4 whitespace-nowrap"><?= $subjectValue ?></td>
                                <td class="px-4 py-4 whitespace-nowrap">
                                    <!-- <button
                                        class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Edit</button> -->
                                         <a href="edit_question.php?id=<?= $Qid ?>"
                                              class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded ml-2">Edit</a>
                                    <a href="delete_question.php?id=<?= $Qid ?>"
                                        class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-2">Delete</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <!-- More rows can be added here -->
                    </tbody>
                </table>
            </div>

        </div>
    </div>
    </div>
    <?php include_once ("./includes/footer.php"); ?>
</body>

</html>
<script>
    document.getElementById('openPopupBtn').addEventListener('click', function () {
        document.getElementById('popup').classList.remove('hidden');
    });

    document.getElementById('closePopupBtn').addEventListener('click', function () {
        document.getElementById('popup').classList.add('hidden');
    });
</script>