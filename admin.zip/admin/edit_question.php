<?php
include_once("./includes/connection.php");

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $question = $_POST['question'];
    $media = '';

    if (!empty($_FILES['image']['name'])) {
        // Handle image upload
        $targetDirectory = "../question_uploads/";
        $targetFile = $targetDirectory . uniqid() . '.' . pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        if ($_FILES["image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        if (!in_array($imageFileType, ["jpg", "jpeg", "png", "gif"])) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $media = basename($targetFile);
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }

    if (!empty($question) || !empty($media)) {
        $mediaUpdate = $media ? ", media='$media'" : "";
        $sql = "UPDATE `questions` SET `question`='$question' $mediaUpdate WHERE `id`=$id";
        $query = mysqli_query($conn, $sql);
        if ($query) {
            header("Location: questions.php");
            exit();
        } else {
            echo "Database update failed.";
        }
    } else {
        echo "Please provide either a text question or an image.";
    }
}

$query = "SELECT * FROM questions WHERE id=$id";
$result = mysqli_query($conn, $query);
$question = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Question</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }

        label {
            display: block;
            margin-top: 10px;
        }

        textarea {
            display: block;
            width: 100%;
            height: 150px;
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        input[type="file"] {
            display: block;
            margin-top: 10px;
        }

        img {
            display: block;
            margin-top: 10px;
            max-width: 100%;
        }

        input[type="submit"] {
            margin-top: 20px;
            background-color: #28a745;
            color: white;
            padding: 15px 30px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <h1>Edit Question</h1>
    <form action="edit_question.php?id=<?= $id ?>" method="POST" enctype="multipart/form-data">
        <label for="question">Edit Your Question</label>
        <textarea name="question" id="question"><?= htmlspecialchars($question['question']); ?></textarea>
        
        <label for="image">Upload Image</label>
        <input type="file" name="image" id="image" accept="image/*">
        <?php if (!empty($question['media'])): ?>
            <img src="../question_uploads/<?= $question['media'] ?>" alt="Current Image">
        <?php endif; ?>
        
        <input type="submit" name="submit" value="Update Question">
    </form>
</body>
</html>
